#pragma once


extern "C" int g;                               

extern "C" int _cdecl min(int, int, int);      
extern "C" int _cdecl p(int, int, int, int);    
extern "C" int _cdecl gcd(int, int);            
